import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

// 
import { UserService } from '../providers/user-service';
import { HttpHelper } from '../helper/http.helper';
import { HttpModule } from '@angular/http';
import { Stripe } from '@ionic-native/stripe/ngx';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
//import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { Camera } from '@ionic-native/camera';

// 
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { DiscoverPage } from '../pages/discover/discover';
import { categoryPage } from '../pages/category/category';
import { home2Page } from '../pages/home2/home2';
import { home3Page } from '../pages/home3/home3';
import { collectionPage } from '../pages/collection/collection';
import { cartPage } from '../pages/cart/cart';



import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ProductDetailsPage } from '../pages/productDetails/productDetails';
import { SearchProductPage } from '../pages/searchProduct/searchProduct';
import { checkOutPage } from '../pages/checkOut/checkOut';
import { add2CartPage } from '../pages/add2Cart/add2Cart';
import { chose_materialPage } from '../pages/chose_material/chose_material';
import { sharePage } from '../pages/share/share';
import { settingPage } from '../pages/setting/setting';
import { searchResultPage } from '../pages/searchResult/searchResult';
import { summaryPage } from '../pages/summary/summary';
import { visitLinkPage } from '../pages/visitLink/visitLink';
import { itemNamePage } from '../pages/itemName/itemName';
import { MyOrderPage } from '../pages/myOrder/myOrder';
import { productReturnPage} from '../pages/productReturn/productReturn';
import { PSRPage } from '../pages/psr/psr';
import { ShippingAddressPage } from '../pages/shippingAddress/shippingAddress';
import { PaymentDetailsPage } from '../pages/paymentDetails/paymentDetails';
import { squaredBoxPage } from '../pages/squaredBox/squaredBox';
import { suportRequestsPage } from '../pages/suportRequests/suportRequests';
import { uploadFilesPage } from '../pages/uploadFiles/uploadFiles';
import { persnoliseserviceAnsPage } from '../pages/persnoliseserviceAns/persnoliseserviceAns';
import { supportPage } from '../pages/support/support';
import { SubscriptionPage } from '../pages/subscriptionPack/subscriptionPack';
import { SlicingSettingPage } from '../pages/slicingSetting/slicingSetting';
import { SaveSettingPage } from '../pages/saveSetting/saveSetting';
import { ForgetPwdPage } from '../pages/forgetPwd/forgetPwd';
import { categoryFilterPage } from '../pages/categoryFilter/categoryFilter';
import { sortByPage } from '../pages/sortBy/sortBy';
import { ProductReturnNewPage } from '../pages/productReturnNew/productReturnNew';
import { PSRGeneratePage } from '../pages/psrGenerate/psrGenerate';
import { SupportNewPage } from '../pages/supportNew/supportNew';
import { SupportRequestNewPage } from '../pages/supportRequestNew/supportRequestNew';
import { ShippingDetailsPage } from '../pages/shippingDetails/shippingDetails';
import { ShippingAddressModalPage } from '../pages/modal/shippingAddressModal/shippingAddressModal';
import { UserDetailsModalPage } from '../pages/modal/userDetailsModal/userDetailsModal';
import { InformationModalPage } from '../pages/modal/information/information';
import { LanguageSettingModalPage } from '../pages/modal/languageSettingModal/languageSettingModal';
import { PaymentDetailsModalPage } from '../pages/modal/paymentDetailsModal/paymentDetailsModal';
import { SelectSubscriptionModalPage } from '../pages/modal/selectSubscription/selectSubscription';
import { PrintModalPage } from '../pages/modal/printModal/printModal';
import { platformChangeModalPage } from '../pages/modal/platformChange/platformChange';
import { AdvancedSettingModalPage } from '../pages/modal/advancedSettingModal/advancedSettingModal';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    DiscoverPage,
    categoryPage,
    home2Page,
    home3Page,
    ProductDetailsPage,
    collectionPage,
    cartPage,
    SearchProductPage,
    checkOutPage,
    add2CartPage,
    chose_materialPage,
    sharePage,
    settingPage,
    searchResultPage,
    summaryPage,
    visitLinkPage,
    itemNamePage,
    MyOrderPage,
    PSRPage,
    ShippingAddressPage,
    PaymentDetailsPage,
    squaredBoxPage,
    suportRequestsPage,
    uploadFilesPage,
    productReturnPage,
    persnoliseserviceAnsPage,
    supportPage,
    SubscriptionPage,
    SlicingSettingPage,
    SaveSettingPage,
    ForgetPwdPage,
    categoryFilterPage,
    sortByPage,
    ProductReturnNewPage,
    PSRGeneratePage,
    SupportNewPage,
    SupportRequestNewPage,
    ShippingDetailsPage,
    ShippingAddressModalPage,
    UserDetailsModalPage,
    InformationModalPage,
    LanguageSettingModalPage,
    PaymentDetailsModalPage,
    SelectSubscriptionModalPage,
    PrintModalPage,
    AdvancedSettingModalPage,
    platformChangeModalPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    DiscoverPage,
    categoryPage,
    home2Page,
    home3Page,
    ProductDetailsPage,
    collectionPage,
    cartPage,
    SearchProductPage,
    checkOutPage,
    add2CartPage,
    chose_materialPage,
    sharePage,
    settingPage,
    searchResultPage,
    summaryPage,
    visitLinkPage,
    itemNamePage,
    MyOrderPage,
    PSRPage,
    ShippingAddressPage,
    PaymentDetailsPage,
    squaredBoxPage,
    suportRequestsPage,
    uploadFilesPage,
    productReturnPage,
    persnoliseserviceAnsPage,
    supportPage,
    SubscriptionPage,
    SlicingSettingPage,
    SaveSettingPage,
    ForgetPwdPage,
    categoryFilterPage,
    sortByPage,
    ProductReturnNewPage,
    PSRGeneratePage,
    SupportNewPage,
    SupportRequestNewPage,
    ShippingDetailsPage,
    ShippingAddressModalPage,
    UserDetailsModalPage,
    InformationModalPage,
    LanguageSettingModalPage,
    PaymentDetailsModalPage,
    SelectSubscriptionModalPage,
    PrintModalPage,
    AdvancedSettingModalPage,
    platformChangeModalPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    UserService,
    HttpHelper,
    Stripe,
    File,
    FileTransfer,
    Camera,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
