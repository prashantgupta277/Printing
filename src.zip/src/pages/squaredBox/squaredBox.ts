import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-squaredBox',
  templateUrl: 'squaredBox.html'
})
export class squaredBoxPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
