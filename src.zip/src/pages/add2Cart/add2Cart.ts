import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-add2Cart',
  templateUrl: 'add2Cart.html'
})
export class add2CartPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
