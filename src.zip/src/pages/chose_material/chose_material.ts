import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-chose_material',
  templateUrl: 'chose_material.html'
})
export class chose_materialPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
