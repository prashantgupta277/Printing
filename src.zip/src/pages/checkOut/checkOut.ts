import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-checkOut',
  templateUrl: 'checkOut.html'
})
export class checkOutPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
