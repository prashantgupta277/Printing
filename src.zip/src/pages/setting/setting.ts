import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { sharePage } from '../share/share';
import { SaveSettingPage } from '../saveSetting/saveSetting';

@Component({
  selector: 'page-setting',
  templateUrl: 'setting.html'
})
export class settingPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  share(){
    this.navCtrl.setRoot(sharePage);
  }
  saveSetting(){
    this.navCtrl.setRoot(SaveSettingPage)
  }

}
