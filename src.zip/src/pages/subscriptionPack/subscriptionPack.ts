import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-subscriptionPack',
  templateUrl: 'subscriptionPack.html'
})
export class SubscriptionPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
