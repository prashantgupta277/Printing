import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { cartPage } from '../cart/cart';

@Component({
  selector: 'page-home3',
  templateUrl: 'home3.html'
})
export class home3Page {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  subCat(){
    this.navCtrl.setRoot(HomePage);
  }
  cart(){
    this.navCtrl.setRoot(cartPage);
  }
}
