import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { home2Page } from '../home2/home2';

@Component({
  selector: 'page-saveSetting',
  templateUrl: 'saveSetting.html'
})
export class SaveSettingPage {

  constructor(public navCtrl: NavController) {

  }
  home(){
    this.navCtrl.setRoot(home2Page);
  } 

}
