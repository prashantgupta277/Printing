import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-support',
  templateUrl: 'support.html'
})
export class supportPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
