import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-searchProduct',
  templateUrl: 'searchProduct.html'
})
export class SearchProductPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
