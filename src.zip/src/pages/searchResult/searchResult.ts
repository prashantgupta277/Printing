import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-searchResult',
  templateUrl: 'searchResult.html'
})
export class searchResultPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
