import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { cartPage } from '../cart/cart';

@Component({
  selector: 'page-home2',
  templateUrl: 'home2.html'
})
export class home2Page {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  subCat(){
    this.navCtrl.setRoot(HomePage);
  }
  cart(){
    this.navCtrl.setRoot(cartPage);
  }

}
