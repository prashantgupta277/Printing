import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { MyOrderPage } from '../myOrder/myOrder';

@Component({
  selector: 'page-ProductReturnNew',
  templateUrl: 'ProductReturnNew.html'
})
export class ProductReturnNewPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  subCat(){
    this.navCtrl.setRoot(MyOrderPage);
  }
  send(){
    this.navCtrl.setRoot(MyOrderPage);
  }
  back(){
    this.navCtrl.setRoot(MyOrderPage);
  }

}
