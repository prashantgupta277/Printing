import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { home2Page } from '../home2/home2';

@Component({
  selector: 'page-share',
  templateUrl: 'share.html'
})
export class sharePage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  home(){
    this.navCtrl.setRoot(home2Page);
  } 


}
