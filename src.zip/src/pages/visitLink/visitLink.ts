import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-visitLink',
  templateUrl: 'visitLink.html'
})
export class visitLinkPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
