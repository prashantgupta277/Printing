import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { suportRequestsPage } from '../suportRequests/suportRequests';

@Component({
  selector: 'page-persnoliseserviceAns',
  templateUrl: 'persnoliseserviceAns.html'
})
export class persnoliseserviceAnsPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  request(){
    this.navCtrl.setRoot(suportRequestsPage)
  }

}
