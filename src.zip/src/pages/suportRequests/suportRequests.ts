import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-suportRequests',
  templateUrl: 'suportRequests.html'
})
export class suportRequestsPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
