import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-shippingAddress',
  templateUrl: 'shippingAddress.html'
})
export class ShippingAddressPage {

  constructor(public navCtrl: NavController) {

  }

}
