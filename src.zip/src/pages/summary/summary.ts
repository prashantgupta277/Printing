import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-summary',
  templateUrl: 'summary.html'
})
export class summaryPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

}
