import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { home2Page } from '../home2/home2';

@Component({
  selector: 'page-productReturn',
  templateUrl: 'productReturn.html'
})
export class productReturnPage {
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }
  home(){
    this.navCtrl.setRoot(home2Page);
  } 

}
